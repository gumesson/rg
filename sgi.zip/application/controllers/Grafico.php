<?php 

function Grafico(){
		// Carregamos a library PHPlot
		$this->load->library('PHPlot');

		//Definindo os dados do gr�fico
		$dados = array(
			array('a',3),
			array('b',5),
			array('c',7),
			array('d',8),
			array('e',2),
			array('f',6),
			array('g',7)
		);
		$this->phplot->SetDataValues($dados);

		//Imprimindo o gr�fico na tela
		$this->phplot->DrawGraph();
	}
	
?>