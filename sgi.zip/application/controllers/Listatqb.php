<?php

defined('BASEPATH') OR exit ('No direct script access allowed');

class Listatqb extends CI_Controller{
	
	function __construct(){
		parent::__construct();
		/*Carrega o modelo */
		$this->load->model('Tqb_model', 'model', TRUE);
	}
	
	function index(){
		$this->load->helper('form');
		$data['titulo'] = 'Lista de chamados';
		$data['tqb'] = $this->model->listar();
		$this->load->view('relatorio_view.php', $data);
	}
	
	
	
}