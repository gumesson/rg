<?php if (! defined('BASEPATH')) exit('No direct script access allowed'); // linha de prote��o ao controller
 
class Inicial extends CI_Controller{ // cria��o da classe Login
 
    public function index(){
	
        $this->load->view("sistema/inicial_view.php");
    
	}
}

?>