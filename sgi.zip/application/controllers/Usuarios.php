<?php
 
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Usuarios extends CI_Controller {
 
    function __construct() {
        parent::__construct();
        /* Carrega o modelo */
    	$this->load->model('Usuarios_model', 'model', TRUE);
 
    }
 

    function index(){
    	$this->load->helper('form');
    	$data['titulo'] = "Cadastro de Usu�rios";
    	$data['usuarios'] = $this->model->listar();
    	$this->load->view('usuarios_view.php', $data);
    }
    
    
    function inserir() {
    
    	/* Carrega a biblioteca do CodeIgniter respons�vel pela valida��o dos formul�rios */
    	$this->load->library('form_validation');
    
    	/* Define as tags onde a mensagem de erro ser� exibida na p�gina */
    	$this->form_validation->set_error_delimiters('<span>', '</span>');
    
    	/* Define as regras para valida��o */
    	$this->form_validation->set_rules('nome', 'Nome', 'required|max_length[40]');
    	$this->form_validation->set_rules('email', 'E-mail', 'required|valid_email|max_length[100]');
    	$this->form_validation->set_rules('senha', 'Senha', 'required');
    
    	/* Executa a valida��o e caso houver erro chama a fun��o index do controlador */
    	if ($this->form_validation->run() === FALSE) {
    		$this->index();
    		/* Sen�o, caso sucesso: */
    	} else {
    		/* Recebe os dados do formul�rio (vis�o) */
    		$data['nome'] = $this->input->post('nome');
    		$data['email'] = $this->input->post('email');
    		$data['senha'] = $this->input->post('senha');
    
    
    		/* Chama a fun��o inserir do modelo */
    		if ($this->model->inserir($data)) {
    			redirect('usuarios');
    		} else {
    			log_message('error', 'Erro ao inserir o usu�rios.');
    		}
    	}
    }
    
    function editar($id)  {
    
    	/* Aqui vamos definir o t�tulo da p�gina de edi��o */
    	$data['titulo'] = "Editar Usu�rio";
    
    	/* Busca os dados do usu�rio que ser� editada */
    	$data['dados_usuario'] = $this->model->editar($id);
    
    	/* Carrega a p�gina de edi��o com os dados do usu�rio */
    	$this->load->view('usuarios_edit', $data);
    }
    
    function atualizar() {
    
    	/* Carrega a biblioteca do CodeIgniter respons�vel pela valida��o dos formul�rios */
    	$this->load->library('form_validation');
    
    	/* Define as tags onde a mensagem de erro ser� exibida na p�gina */
    	$this->form_validation->set_error_delimiters('<span>', '</span>');
    
    	/* Aqui estou definindo as regras de valida��o do formul�rio, assim como
    	 na fun��o inserir do controlador, por�m estou mudando a forma de escrita */
    	$validations = array(
    			array(
    					'field' => 'nome',
    					'label' => 'Nome',
    					'rules' => 'trim|required|max_length[40]'
    			),
    			array(
    					'field' => 'email',
    					'label' => 'E-mail',
    					'rules' => 'trim|required|valid_email|max_length[100]'
    			),
    			array(
    					'field' => 'senha',
    					'label' => 'Senha',
    					'rules' => 'required'
    			)
    	);
    	$this->form_validation->set_rules($validations);
    
    	/* Executa a valida��o e caso houver erro chama a fun��o editar do controlador novamente */
    	if ($this->form_validation->run() === FALSE) {
    		$this->editar($this->input->post('id'));
    	} else {
    		/* Sen�o obt�m os dados do formul�rio */
    		$data['id'] = $this->input->post('id');
    		$data['nome'] = ucwords($this->input->post('nome'));
    		$data['email'] = strtolower($this->input->post('email'));
    
    		/* Executa a fun��o atualizar do modelo passando como par�metro os dados obtidos do formul�rio */
    		if ($this->model->atualizar($data)) {
    			redirect('usuarios');
    		} else {
    			log_message('error', 'Erro ao atualizar o usu�rio.');
    		}
    	}
    }
    
    function deletar($id) {
    
    	/* Executa a fun��o deletar do modelo passando como par�metro o id do usu�rio */
    	if ($this->model->deletar($id)) {
    		redirect('usuarios');
    	} else {
    		log_message('error', 'Erro ao deletar o usu�rio.');
    	}
    }
    
    
}

?>
