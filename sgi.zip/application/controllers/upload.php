<?php

//adaptado de: http://www.dicascodeigniter.com.br/importando-um-arquivo-csv-para-um-banco-de-dados/

class Upload extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper(array('form', 'url'));
	}

	function index(){
		$this->load->view('upload_form', array('error' => ' ' ));
	}

	function do_upload(){
		$config['upload_path'] = './uploads/';
		$config['allowed_types'] = '*';
		$config['max_size']	= '100';
		$config['max_width']  = '1024';
		$config['max_height']  = '768';

		$this->load->library('upload', $config);

		if ( ! $this->upload->do_upload()){
			$error = array('error' => $this->upload->display_errors());

			$this->load->view('upload_form', $error);
		}
		else{
			$this->load->helper('file');			
			$this->load->database();
			
			$dados = $this->upload->data();
 			
			$arquivo = fopen($dados['full_path'], "r");
 			
			$linha = 1;
			
			while (($data = fgetcsv($arquivo, 1000, ",")) !== FALSE) {
					
				if ($linha++ == 1)
					continue;
				
			    $sql = "INSERT INTO TABELA(tqb_solici, tqb_codbem, tqb_usuari, tqb_dtaber, tqb_dtfech, tqb_ccusto, tqb_cdserv, tqb_cdexec) VALUES('". $data[0] ."', '". $data[1] ."', '". $data[2] ."', '". $data[3] ."', '". $data[4] ."', '". $data[5] ."',, '". $data[6] ."',, '". $data[7] ."')";
				
				$dados = array(
					"tqb_solici" => $data[0],
					"tqb_codbem" => $data[1],
					"tqb_usuari" => $data[2],
					"tqb_dtaber" => $data[3],
					"tqb_dtfech" => $data[4],
					"tqb_ccusto" => $data[5],
					"tqb_cdserv" => $data[6],
					"tqb_cdexec" => $data[7]
				);
				
				$this->db->insert("tqb", $dados);
			}
			
			fclose ($arquivo);
			
			$variaveis['status'] = "Importa��o conclu�da com sucesso.";
			
			$variaveis['upload_data'] = $this->upload->data();

			$this->load->view('upload_success', $variaveis);
		}
	}
}
?>